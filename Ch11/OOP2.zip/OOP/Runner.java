public class Runner {
    
    public static void main () {
        main(null);
    }
    
    public static void main (String [] args) {
        ColorRectangle cr1 = new ColorRectangle(3,7,10,13);
        ColorRectangle cr2 = new ColorRectangle(2,7,10,13);
        System.out.println(cr1);
        System.out.println(cr2);
        System.out.println("Equal? " + cr1.equals(cr2));
        ColorRectangle cr3 = new ColorRectangle(5,6,7,8);
        System.out.println(cr3);
        System.out.println("Equal? " + cr1.equals(cr3));
        
        System.out.println("Same color? " + 
            cr1.getColor().equals(cr2.getColor() ) ) ;
    }
    
}
