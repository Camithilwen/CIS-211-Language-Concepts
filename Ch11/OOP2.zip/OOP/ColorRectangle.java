import java.awt.Color;

public class ColorRectangle {
    private int x, y, w, h;
    private Color color;
    
    public ColorRectangle (int x, int y, int w, int h) {
        // save parameter values in instance variables
        // instance_variable = parameter_value
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.color = Color.BLACK;
    }
    
    // SETTER and GETTER
    // MUTATOR and ACCESSOR
    public void setColor (Color c) {
        if (c != null) {
            this.color = c;
        }
    }
    
    public Color getColor () {
        return this.color;
    }
    
    public boolean equals (ColorRectangle other) {
        return this.w==other.w && this.h==other.h;
    }
    
    @Override
    public String toString () {
        return "Rect width=" + w + " height=" +h;
    }
    
}
