public class ColorRectangle {
// extends Object {   // optional, but compiler inserts it
  
    // instance variables, also called attributes
    private int x, y, w, h;
    
    // constructor
    public ColorRectangle (int x, int y, int w, int h) {
        // save parameter values in instance variables
        // instance_variable = parameter_value
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
    }
    
    @Override
    public String toString () {
        return "Rect width=" + w + " height=" +h;
    }
    
}
