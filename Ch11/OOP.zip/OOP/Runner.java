public class Runner {
    
    public static void main () {
        main(null);
    }
    
    public static void main (String [] args) {
        // call the default constructor
        ColorRectangle cr1 = new ColorRectangle(5,3,10,13);
        System.out.println(cr1);
    }
    
}
