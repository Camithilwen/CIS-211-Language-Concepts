import javax.swing.JFrame;
import java.awt.*;
import java.awt.event.*;

/**
 * Conway's Game of Life.
 * Set up objects.
 * Start the game.
 */
public class GameOfLife 
extends MouseAdapter 
implements ActionListener {
    Button nextButton;
    Button presetButton;
    GameView gameView;
    GameModel gameModel;
    JFrame frame;
    final static int GRID_SIZE = 20; // in cells
    final static int CELL_SIZE = 20; // in pixels
    
    public static void main () {
        main(null);
    }
    public static void main (String [] args) {
        GameOfLife game = new GameOfLife();
    }
    
    public GameOfLife () {
        frame = new JFrame("Game");
        frame.setVisible(false);
        frame.setLayout(new FlowLayout());
        frame.setBackground(Color.green);

        gameModel = new GameModel(GRID_SIZE,GRID_SIZE,CELL_SIZE);
        gameView = new GameView(gameModel);
        gameView.addMouseListener(this);
        frame.add(gameView);

        Panel buttons = new Panel();
        buttons.setLayout(new FlowLayout());
        presetButton = new Button ("PRESET");
        presetButton.addActionListener(this);
        buttons.add(presetButton);
        nextButton = new Button ("NEXT");
        nextButton.addActionListener(this);
        buttons.add(nextButton);        
        frame.add(buttons);

        frame.pack();
        frame.setVisible(true);
    }
        
    public void actionPerformed (ActionEvent e) {
        Object src = e.getSource();
        if (src == nextButton) {
            gameModel.advanceOneGeneration();            
        } else if (src == presetButton) {
            Presets presets = new Presets(gameModel);
            presets.preset1();
        }
        gameView.repaint();
    }
    
    public void mouseClicked(MouseEvent me)    {
        Point p = me.getPoint();
        gameView.toggleCellAtPoint(p);
        gameView.repaint();
    }
    
}
