
public class __SHELL14 extends bluej.runtime.Shell {
public static void run() throws Throwable {

Game.main();

}}
