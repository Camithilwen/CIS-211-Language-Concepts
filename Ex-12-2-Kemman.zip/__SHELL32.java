
public class __SHELL32 extends bluej.runtime.Shell {
public static void run() throws Throwable {

Game.main();

}}
