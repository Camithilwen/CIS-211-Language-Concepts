
public class __SHELL10 extends bluej.runtime.Shell {
public static void run() throws Throwable {

Game.main();

}}
