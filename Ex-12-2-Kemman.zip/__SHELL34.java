
public class __SHELL34 extends bluej.runtime.Shell {
public static void run() throws Throwable {

Game.main();

}}
