
public class __SHELL33 extends bluej.runtime.Shell {
public static void run() throws Throwable {

Game.main();

}}
