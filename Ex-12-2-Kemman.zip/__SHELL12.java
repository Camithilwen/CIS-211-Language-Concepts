
public class __SHELL12 extends bluej.runtime.Shell {
public static void run() throws Throwable {

Game.main();

}}
